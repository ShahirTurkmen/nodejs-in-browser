'use strict';

// This module exists entirely for regression testing purposes.
// See `test/parallel/test-internal-unicode.js`.

module.exports = '✓';
