'use strict';

// This is needed still for FastBuffer
module.exports = {};
